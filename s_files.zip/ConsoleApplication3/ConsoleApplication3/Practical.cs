﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Practical
    {
        public void mainpro()
        {
            Dictionary<int, string> pokemon = new Dictionary<int, string>();
            pokemon.Add(1, "Pickachu :Thunder shock and quick attack and looks yellow");
            pokemon.Add(2, "Charmendor: Fire attack and fire blast and looks red ");
            pokemon.Add(3, "Blastoise: Water pump and water blast and looks blue");
            pokemon.Add(4, "Ivysaur: Grass attack and beam and looks green");


            Dictionary<int, string> pokemonext = new Dictionary<int, string>()
            {
                { 1, "Pickachu :Thunder shock and quick attack and looks yellow" },
                { 2, "Charmendor: Fire attack and fire blast and looks red " },
                { 3, "Blastoise: Water pump and water blast and looks blue" },
                { 4, "Ivysaur: Grass attack and beam and looks green" }
        };

            foreach (KeyValuePair<int, string> item in pokemon)
            {
                Console.WriteLine("pokemon name {0} and the description {1}", item.Key, item.Value);
            }

            Console.WriteLine("-----------------------------------------------------------------------");

            for (int i = 0; i < pokemonext.Count; i++)
            {
                Console.WriteLine("pokemon name {0} and the description {1}", pokemonext.Keys.ElementAt(i),
                                                                              pokemonext[pokemonext.Keys.ElementAt(i)]);
            }
            Console.WriteLine("-----------------------------------------------------------------------");

            Console.WriteLine(pokemon[1]);

            Console.WriteLine("-----------------------------------------------------------------------");

            string valuepok;

            if (pokemon.TryGetValue(3, out valuepok))
            {
                Console.WriteLine(valuepok);
            }
            else
            {
                Console.WriteLine("Your result for the output is unknown");
            }

            Console.WriteLine("-----------------------------------------------------------------------");

            Console.WriteLine(pokemonext.ContainsKey(3));//return true;
            Console.WriteLine(pokemonext.ContainsKey(5));//return false;

            Console.WriteLine(pokemonext.Contains(new KeyValuePair<int, string>(1, "Pickachu")));
            Console.WriteLine(pokemonext.Contains(new KeyValuePair<int, string>(1, "Pickachu :Thunder shock and quick attack and looks yellow")));

            Console.ReadLine();
        }
    }
}
