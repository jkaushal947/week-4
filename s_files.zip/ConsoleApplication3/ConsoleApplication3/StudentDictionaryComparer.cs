﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace ConsoleApplication3
{
    internal class StudentDictionaryComparer : IEqualityComparer<KeyValuePair<int, Student>>
    {
        public bool Equals(KeyValuePair<int, Student> x, KeyValuePair<int, Student> y)
        {
            if (x.Key == y.Key && (x.Value.StudentId == y.Value.StudentId) && (x.Value.StudentName == y.Value.StudentName))

                return true;
            return false;

        }

        public int GetHashCode(KeyValuePair<int, Student> obj)
        {
            return obj.Key.GetHashCode();
        }
    }
}