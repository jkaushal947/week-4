﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class classPract
    {
        public void upmain()
        {
            IDictionary<int, Student> students = new Dictionary<int, Student>
        {
            {1,new Student() {StudentId = 101, StudentName="Charmendor" } },
            {2,new Student() {StudentId = 102, StudentName="Pikachu" } },
            {3, new Student() {StudentId = 103, StudentName = "Blastoise" } },
            {4,new Student() {StudentId = 104, StudentName = "Ivosor" } }
        };

            students.Add(5, new Student() { StudentId = 105, StudentName = "New Generation" });

            students.Remove(3);

            Student std = new Student() { StudentId = 106, StudentName = "Charmendor" };
            students.Add(6,std);

            KeyValuePair<int, Student> studentToFind = new KeyValuePair<int, Student>(7, std);

            bool result = students.Contains(studentToFind, new StudentDictionaryComparer());

            Console.WriteLine("Found Student? {0}", result);

            for (int i = 0; i < students.Count; i++)
            {
                Console.WriteLine("{0} is registered as {1} and {2}", students.Keys.ElementAt(i),
                                                                students[students.Keys.ElementAt(i)].StudentId,
                                                                students[students.Keys.ElementAt(i)].StudentName);
            }

            foreach (KeyValuePair<int, Student> item in students)
            {
                Console.WriteLine("pokemon name {0} and the description {1} and {2}", item.Key, item.Value.StudentName, item.Value.StudentId);
            }
        }




    }
}
