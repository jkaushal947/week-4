﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppWeek4
{
    class Program
    {
        public static List<string> books;
        static void Main(string[] args)
        {
            books = new List<string>
            {
                "C# for beginners","HTML Fundamentals","CSS for positioning","JS for the visual"
            };

            listResult();
            books.Sort();
            displayResult();

            Console.ReadKey();
        }
        static void listResult()
        {
            Libbooks lib = new Libbooks();
            Console.WriteLine("Press A to add a new book and Z to delete and Y to search and X to quit");
            char xinput = Convert.ToChar(Console.ReadLine());
            switch (xinput)
            {
                case 'A':
                    Console.WriteLine("You pressed Y");
                    lib.Add(books);
                    break;

                case 'Z':
                    Console.WriteLine("You Pressed Z");
                    lib.Delete(books);
                    break;
                case 'Y':
                    Console.WriteLine("You Pressed Y");
                    searchresult();
                    break;

                case 'X':
                    Console.WriteLine("You press X");
                    displayResult();
                    break;
                default:
                    Console.WriteLine("Your input is invalid");
                    break;
            }
        }

        static void displayResult()
        {
            for (int i = 0; i < books.Count; i++)
            {
                Console.WriteLine(books[i]);
            }
        }

        static void searchresult()
        {
            Console.WriteLine("Type the name of the book , you would like to search!");
            string xbook = Console.ReadLine();

            string result = books.Find(x => x == xbook);
            Console.WriteLine(result+ "is in the list \n");

        }
    }
}
