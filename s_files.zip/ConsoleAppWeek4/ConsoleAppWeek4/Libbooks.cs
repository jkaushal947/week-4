﻿using System;
using System.Collections.Generic;

namespace ConsoleAppWeek4
{
    internal class Libbooks
    {
        public Libbooks()
        {
        }

        public List<string> Add(List<string> book)
        {
            Console.WriteLine("Type the name of the book , you would like to add!");
            string xbook = Console.ReadLine();
            book.Add(xbook);
            return (book);
        }

        internal List<string> Delete(List<string> book)
        {
            Console.WriteLine("Type the name of the book , you would like to Remove!");
            string xbook = Console.ReadLine();
            book.Remove(xbook);
            return (book);
        }
      
    }
}