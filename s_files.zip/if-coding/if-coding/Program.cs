﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace if_coding
{
    class Program
    {
        static void Main(string[] args)
        {
            //exercise();
            Console.WriteLine("You get 5 chances");
            Random rd = new Random();
            int magicnumber = rd.Next(1, 6);

            exercise2(magicnumber);
            Console.ReadKey();
        }
     
        static void exercise2(int magicnumber)
        {
            int i = 0;
            do
            {
                Console.WriteLine("Guess a number " + "You  used " + i + " chance ");
                int guess = Convert.ToInt16(Console.ReadLine());

                if (guess == magicnumber)
                {
                    Console.WriteLine("You are correct");
                    break;
                }
                else
                {
                    Console.WriteLine("Try again");
                }
                i++;
            } while (i < 5);
        }
        
    }
}
