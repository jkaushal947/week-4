﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class ClassPract
    {
        public void arrayofnumber()
        {
            int[] arrayofnumbers = { 21, 22, 23, 25, 26, 27 };
            foreach (int i in arrayofnumbers)
            {
                Console.WriteLine(i);
            }
            for (int j = 0; j < 6; j++)
            {
                Console.WriteLine(arrayofnumbers[j]);
            }
            Console.Read();
        }
    }
}
