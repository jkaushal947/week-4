﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace ConsoleApp
{
    class Program2
    {
        public void outputmain()
        {
            Console.WriteLine(apexTrigger(Console.ReadLine()));
        }

        private static string apexTrigger(string inputstrg)
        {
            string newBigstring = "";
            string cleaninputstrg = RemoveSpecialCharacters(inputstrg);

            string[] arrayinputstrgs = cleaninputstrg.Split(' ');

            foreach (var arrayinputstrg in arrayinputstrgs)
            {
                if (arrayinputstrg.Length > newBigstring.Length)
                {
                    newBigstring = arrayinputstrg;
                }
            }
            return newBigstring;
        }

        private static string RemoveSpecialCharacters(string str)
        {
            return Regex.Replace(str, "[^a-zA-Z0-9_.]+", " ", RegexOptions.Compiled);
        }
    }
}
