﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Program3
    {
     
        public int FirstFactorial(int num)
        {
            for (int i = num - 1; i > 0; i--)
            
                //for (int i = 0; i < num; i++)
            {
                num = num * i;
            }
            return num;
        }
    }
}
