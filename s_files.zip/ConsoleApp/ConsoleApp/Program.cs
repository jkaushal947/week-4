﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] sevenDwarves = { "Happy", "Doc", "Sleepy"};
            string[] drinks = new string[sevenDwarves.Length];
            string[] dinner = new string[sevenDwarves.Length];

            for (int i = 0; i < sevenDwarves.Length; i++)
            {
                Console.WriteLine("What would you like for a drink " + sevenDwarves[i]);
                drinks[i] = Console.ReadLine();
                Console.WriteLine("and What would you like for a dinner");
                dinner[i] = Console.ReadLine();
            }

            var numbersAndWords = sevenDwarves.Zip(drinks, (n, w) => n + " drink " + w + " is ready!" + "and your dinner").Zip(dinner,(n,w) => n + w);
            foreach (var nw in numbersAndWords)
            {
                Console.WriteLine(nw);
            }
            Console.ReadKey();
        }

    }
}
