﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppArrays
{
    class Program
    {
        static void Main(string[] args)
        {
            twoArrat();
            Console.ReadKey();

        }

        static void twoArrat()
        {
            string[,] students = new string[,]
            {
                {"Studentid","Name","Gender" },
                {"P12567","Jackie","F" },
                {"P12544","Dimeon","M" },
                                {"P12544","Dimeon","M" },

                                                {"P12544","Dimeon","M" },

                                                                {"P12544","Dimeon","M" },

                {"P12333","Mike","M" }
            };

            for (int i = 0; i <= students.GetUpperBound(0); i++)
            {
                Console.WriteLine("{0}, {1}, {2}", students[i,0],students[i,1],students[i,2]);
            }

        }
    }
}
